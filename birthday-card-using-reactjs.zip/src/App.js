import Card from "./Card";
import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <Card />
    </div>
  );
}
